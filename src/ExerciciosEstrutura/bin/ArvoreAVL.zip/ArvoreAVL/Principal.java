package ArvoreAVL;

public class Principal {
	public static void main(String[] args) {
		Corpo e = new Corpo();
		e.entrada();
	}

}
